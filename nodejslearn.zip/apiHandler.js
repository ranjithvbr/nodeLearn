const addCall = require('./routes/addCall');
const insertStudentDetails = require('./routes/insertStudentDetails');

let apiHandler = {
    init: function (app, router, db, async) {
        let version = "/test"
        app.use(version, addCall(router, db, async))
        app.use(version, insertStudentDetails(router, db, async))
    }
}

module.exports = apiHandler;